class Super {


}

public class Main extends Super {

public static  void main( String[] args) {
}


}

